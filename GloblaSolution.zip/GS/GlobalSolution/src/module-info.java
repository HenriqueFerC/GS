/**
 * 
 */
/**
 * @author Rik
 *
 */
module GlobalSolution {
	requires java.desktop;
}